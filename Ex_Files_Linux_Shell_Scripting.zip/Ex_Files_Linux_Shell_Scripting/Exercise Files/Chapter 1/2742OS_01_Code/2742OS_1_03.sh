#!/bin/bash
#Desc: Number conversion

no=100
echo "obase=2;$no" | bc

